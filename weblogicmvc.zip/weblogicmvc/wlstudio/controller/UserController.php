<?php
use ArmoredCore\Controllers\BaseController;
use ArmoredCore\WebObjects\Post;
use ArmoredCore\WebObjects\Redirect;
use ArmoredCore\WebObjects\Session;
use ArmoredCore\WebObjects\View;
use ArmoredCore\Interfaces\ResourceControllerInterface;

class UserController extends BaseController implements ResourceControllerInterface
{

    public function index()
    {
        View::make('user.stb_login');
    }

    public function create()
    {
        View::make('user.stb_registar');
    }

    public function login()
    {
        $user = User::find_by_username_and_password(Post::get('username'), Post::get('password'));

        \Tracy\Debugger::barDump($user);

        if (is_null($user) || $user ->estado == 'b') {
            // redirect to standard error page
            // return form with data and errors
            Redirect::toRoute('user/index');
        } else {
            $user -> username = Post::get('username');
            session::set('LOGIN', $user);
            View::make('stb.stb_index', ['user' => $user]);
        }
    }

    public function store()
    {
        // create new resource (activerecord/model) instance
        // your form name fields must match the ones of the table fields
        $user = new User(Post::getAll());

        if($user->is_valid()){
            $user->save();
            Redirect::toRoute('stb/stb_index');
        } else {
            // return form with data and errors
            Redirect::flashToRoute('user/create', ['user' => $user]);
        }
    }

    public function edit($id)
    {
        $user = User::find($id);

        if (is_null($user)) {
            // redirect to standard error page
        } else {
            View::make('user.stb_edit', ['user' => $user]);
        }
    }

    public function show($id)
    {
        $dev = session::get('LOGIN');

        if($dev ->tipo == 'a')
        {
           $this->devteam();
        }
        else
        {
            $user = User::find($id);

            if (is_null($user)) {
                // redirect to standard error page
            } else {
                View::make('user.stb_show', ['user' => $user]);
            }
        }
    }

    public function destroy($id)
    {

    }

    public function update($id)
    {
        $user = User::find($id);
        $user->update_attributes(array('nome' => post::get('nome'), 'dtanascimento' => post::get('dtanascimento'), 'email' => post::get('email'), 'password' => post::get('password')));

        if($user->is_valid()){
            $user->save();
            Redirect::toRoute('user/show', $user->iduser);
        } else {
            // return form with data and errors
            Redirect::flashToRoute('user/edit', ['user' => $user]);
        }
    }

    public function updatedev($id, $estado)
    {
        $user = User::find($id);
        $user->update_attributes(array('estado' => $estado));

        if($user->is_valid()){
            $user->save();
            $this->devteam();
        } else {
            // return form with data and errors
            Redirect::flashToRoute('user/edit', ['user' => $user]);
        }
    }

    public function devteam()
    {
        $user = User::find('all', array('conditions' => "tipo = 'u'"));

        if (is_null($user)) {
            // redirect to standard error page
        } else {
            View::make('user.stb_list', ['user' => $user]);
        }
    }

    public function action()
    {
        if(Post::has('Desativar'))
        {
            $this ->updatedev(Post::get('Desativar'), 'b');
        }
        else if(Post::has('Ativar'))
        {
            $this ->updatedev(Post::get('Ativar'), 'a');
        }

    }

    public function logout()
    {
        session::destroy('LOGIN');

        Redirect::toRoute('user/index');
    }
}