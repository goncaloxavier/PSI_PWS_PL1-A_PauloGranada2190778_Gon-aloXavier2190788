<?php
use ArmoredCore\Controllers\BaseController;
use ArmoredCore\WebObjects\Post;
use ArmoredCore\WebObjects\Redirect;
use ArmoredCore\WebObjects\Session;
use ArmoredCore\WebObjects\View;
use ArmoredCore\Interfaces\ResourceControllerInterface;

class ScoreController extends BaseController implements ResourceControllerInterface
{

    /**
     * @inheritDoc
     */
    public function index()
    {
        // TODO: Implement index() method.
        $score = Score::find('all', array('order' => 'pontuacao desc'));
        view::make('score.stb_top10', ['score' => $score]);
    }

    /**
     * @inheritDoc
     */
    public function create()
    {
        // TODO: Implement create() method.
    }

    /**
     * @inheritDoc
     */
    public function store()
    {
        // TODO: Implement store() method.
        $STB = session::get('STB');
        $user = session::get('LOGIN');
        $username = User::find($user->iduser);

        $verify = Score::find_by_iduser($username ->iduser);

        if($verify != null)
        {
            $this->update($verify ->idscore);
        }
        else
        {
            $score = new Score(array('iduser' => $username ->iduser, 'pontuacao' => $STB ->points, 'dtapontuacao' => date("Y-m-d H:i:s")));
            \Tracy\Debugger::barDump($score);

            if($score->is_valid()){
                $score->save();
                Redirect::toRoute('score/index');
            } else {
                // return form with data and errors
                Redirect::ToRoute('stb/stb_index');
            }
        }

        $STB = new STB();
        session::set('STB', $STB);
    }

    public function show($id)
    {
        // TODO: Implement show() method.
    }

    public function edit($id)
    {
        // TODO: Implement edit() method.
    }

    public function update($id)
    {
        $score = Score::find($id);
        $STB = session::get('STB');
        $score ->pontuacao = $score ->pontuacao + $STB ->points;
        $score->update_attributes(array('pontuacao' => $score ->pontuacao, 'dtapontuacao' => date("Y-m-d H:i:s")));

        if($score->is_valid()){
            $score->save();
            Redirect::toRoute('score/index');
        } else {
            // return form with data and errors
            Redirect::flashToRoute('stb/stb_index');
        }
    }

    public function destroy($id)
    {
        // TODO: Implement destroy() method.
    }
}