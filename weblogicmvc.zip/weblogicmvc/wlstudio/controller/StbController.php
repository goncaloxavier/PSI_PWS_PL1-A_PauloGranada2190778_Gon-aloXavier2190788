<?php
use ArmoredCore\Controllers\BaseController;
use ArmoredCore\WebObjects\Redirect;
use ArmoredCore\WebObjects\Session;
use ArmoredCore\WebObjects\View;
use ArmoredCore\WebObjects\Post;

class StbController extends BaseController
{
    public function index()
    {
        View::make('stb.stb_index');
    }

    public function roll_index()
    {
        if(session::has('STB'))
        {
            $STB = session::get('STB');
        }
        else
        {
            $STB = new STB();
        }

        if(Post::has('Roll'))
        {
            $STB ->Dice1 = $STB ->rollDice();
            $STB ->Dice2 = $STB ->rollDice();
            $STB ->Sum =  $STB ->Dice1 + $STB ->Dice2;
            $STB ->Somar = true;
        }
        else if(Post::has('Somar'))
        {
            $i = 0;
            for($z=0; $z<9; $z++)
            {
                $array[$z] = 0;
            }

            foreach (Post::getAll() as &$value)
            {
                $array[$i] = $value;
                $STB ->validateCheck[$i] = $array[$i];
                $i++;
            }

            $STB ->SelectedCheck = $STB ->SumALL($array[0], $array[1], $array[2], $array[3], $array[4], $array[5], $array[6], $array[7], $array[8]);

            if($STB->SelectedCheck != $STB->Sum)
            {
                $STB ->Error = true;
                $STB ->Somar = true;
            }
            else
            {
                $STB ->P1 = $STB ->validateCheckBox($STB-> validateCheck, $STB-> P1);
                $STB ->Error = false;
                $STB ->Dice = true;
                $STB ->Somar = false;
            }
        }

        session::set('STB', $STB);
        View::make('stb.stb_index', ['STB' => $STB]);
    }

    public function registar()
    {
        View::make('stb.stb_registar');

    }

    public function login()
    {
        View::make('stb.stb_login');
    }
}