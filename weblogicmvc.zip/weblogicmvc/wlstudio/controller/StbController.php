<?php
use ArmoredCore\Controllers\BaseController;
use ArmoredCore\WebObjects\Redirect;
use ArmoredCore\WebObjects\Session;
use ArmoredCore\WebObjects\View;
use ArmoredCore\WebObjects\Post;

class StbController extends BaseController
{
    public function index()
    {
        if(session::has('LOGIN'))
        {
            View::make('stb.stb_index');
        }
        else
        {
            View::make('user.stb_login');
        }
    }

    public function roll_index()
    {
        if(session::has('STB'))
        {
            $STB = session::get('STB');
        }
        else
        {
            $STB = new STB();
        }

        if(Post::has('Roll'))
        {
            $STB ->Dice = false;
            $STB ->Somar = true;
            Tracy\Debugger::barDump($STB);
            $STB ->Dice1 = $STB ->rollDice();
            $STB ->Dice2 = $STB ->rollDice();
            $STB ->Sum =  $STB ->Dice1 + $STB ->Dice2;

            if($STB ->getPoints($STB->P1) == 8)
            {
                $values = $STB ->getArrayValues($STB->P1);
                $STB ->fimJogo = $STB ->ck1($values[0], $STB ->Sum);
            }
            else if($STB ->getPoints($STB->P1) == 7)
            {
                $values = $STB ->getArrayValues($STB->P1);
                $STB ->fimJogo = $STB ->ck2($values[0], $values[1], $STB ->Sum);
            }
            else if($STB ->getPoints($STB->P1) == 6)
            {
                $values = $STB ->getArrayValues($STB->P1);
                $STB ->fimJogo = $STB ->ck3($values[0], $values[1], $values[2], $STB ->Sum);
            }
            else if($STB ->getPoints($STB->P1) == 5)
            {
                $values = $STB ->getArrayValues($STB->P1);
                $STB ->fimJogo  = $STB ->ck4($values[0], $values[1], $values[2], $values[3], $STB ->Sum);
            }
            else if($STB ->getPoints($STB->P1) == 4)
            {
                $values = $STB ->getArrayValues($STB->P1);
                $STB ->fimJogo  = $STB ->ck5($values[0], $values[1], $values[2], $values[3], $values[4], $STB ->Sum);
            }

            if($STB->fimJogo == true || $STB ->getPoints($STB->P1) == 9)
            {
                $STB ->points = $STB ->getPoints($STB->P1);
                session::set('STB', $STB);
                Redirect::toRoute('score/store');
            }
            \Tracy\Debugger::barDump($STB ->fimJogo);

            $STB->points = $STB ->getPoints($STB->P1);
        }
        else if(Post::has('Somar'))
        {
            $i = 0;
            for($z=0; $z<9; $z++)
            {
                $array[$z] = 0;
            }

            $z = 0;
            $x = 0;
            foreach (Post::getAll() as &$value)
            {
                $array[$z] = $value;
                if($array[$z] != 'Somar')
                {
                    $STB ->validateCheck[$x] = $array[$z];
                    $x ++;
                }
                $z++;
            }

            $STB ->SelectedCheck = $STB ->SumALL($array[0], $array[1], $array[2], $array[3], $array[4], $array[5], $array[6], $array[7], $array[8]);

            if($STB->SelectedCheck != $STB->Sum)
            {
                $STB ->Error = true;
                $STB ->Somar = true;
            }
            else
            {
                $STB ->P1 = $STB ->validateCheckBox($STB-> validateCheck, $STB-> P1);
                $STB ->Error = false;
                $STB ->Dice = true;
                $STB ->Somar = false;
            }

        }

        session::set('STB', $STB);
        View::make('stb.stb_index', ['STB' => $STB]);
    }

    public function top10()
    {
        View::make('stb.stb_top10');
    }

    public function registar()
    {
        View::make('stb.stb_registar');

    }

    public function login()
    {
        View::make('stb.stb_login');
    }
}