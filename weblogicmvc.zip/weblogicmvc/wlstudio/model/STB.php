<?php


class STB
{
    public $Dice1, $Dice2, $P1 = array(1, 2, 3, 4, 5, 6, 7, 8, 9), $validateCheck, $Sum = 0, $SelectedCheck = 0, $Error, $Dice = true, $Somar = false;

    public function rollDice()
    {
        $dice = rand(1, 6);
        return $dice;
    }

    public function SumALL($val1, $val2, $val3, $val4, $val5, $val6, $val7, $val8, $val9)
    {
        return $val1 + $val2 + $val3 + $val4 + $val5 + $val6 + $val7 + $val8 + $val9;
    }

    public function validateCheckBox($array, $P1)
    {
        for($i = 0; $i < sizeof($array); $i++)
        {
            $value = $array[$i];
            $P1[$value - 1] = 0;
        }
        return $P1;
    }

    public function getError()
    {

        return "Erro";
    }
}