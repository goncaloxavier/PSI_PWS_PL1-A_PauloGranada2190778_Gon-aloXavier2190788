<?php


class STB
{
    public $Dice1, $Dice2, $P1 = array(1, 2, 3, 4, 5, 6, 7, 8, 9), $validateCheck, $Sum = 0, $SelectedCheck = 0, $points = 0, $Dice = true, $Somar = false, $fimJogo = false;

    public function rollDice()
    {
        $dice = rand(1, 6);
        return $dice;
    }

    public function SumALL($val1, $val2, $val3, $val4, $val5, $val6, $val7, $val8, $val9)
    {
        return $val1 + $val2 + $val3 + $val4 + $val5 + $val6 + $val7 + $val8 + $val9;
    }

    public function validateCheckBox($array, $P1)
    {
        for($i = 0; $i < sizeof($array); $i++)
        {
            $value = $array[$i];
            $P1[$value - 1] = 0;
        }
        return $P1;
    }

    public function getArrayValues($array)
    {
        $z = 0;
        for($i = 0; $i < 9; $i++)
        {
            if($array[$i] != 0)
            {
                $values[$z] = $array[$i];
                $z++;
            }
        }

        return $values;
    }

    public function getPoints($array)
    {
        $points = 0;
        for($i = 0; $i < sizeof($array); $i++)
        {
            if($array[$i] == 0)
            {
                $points++;
            }
        }
        return $points;
    }

    public function ck3($x, $y, $w, $somaDados)
    {
        $result = $x + $y + $w;
        $fim = true;

        if($somaDados > $result)
        {
            $fim = true;
        }
        else if($somaDados == $result)
        {
            $fim = false;
        }
        else if($w == $somaDados)
        {
            $fim = false;
        }
        else if($y == $somaDados)
        {
            $fim = false;
        }
        else if($x == $somaDados)
        {
            $fim = false;
        }
        else if($x + $y == $somaDados)
        {
            $fim = false;
        }
        else if($x + $w == $somaDados)
        {
            $fim = false;
        }
        else if($y + $w == $somaDados)
        {
            $fim = false;
        }


        return $fim;
    }

    public function ck4($x, $y, $w, $z, $somaDados)
    {
        $fim = true;

        if($x + $y + $w + $z == $somaDados)
        {
            $fim = false;
        }
        if($x + $y + $w + $z < $somaDados)
        {
            $fim = true;
        }
        if($w == $somaDados)
        {
            $fim = false;
        }
        if($y == $somaDados)
        {
            $fim = false;
        }
        if($x == $somaDados)
        {
            $fim = false;
        }
        if($z == $somaDados )
        {
            $fim = false;
        }
        else if($x + $y + $z ==  $somaDados)
        {
            $fim = false;
        }
        else if($x + $y + $w ==  $somaDados)
        {
            $fim = false;
        }
        else if($x + $z + $w ==  $somaDados)
        {
            $fim = false;
        }
        else if($x + $y ==  $somaDados)
        {
            $fim = false;
        }
        if($x + $w + $z ==  $somaDados)
        {
            $fim = false;
        }
        if($x + $w == $somaDados)
        {
            $fim = false;
        }
        if($x + $z == $somaDados)
        {
            $fim = false;
        }
        if($y + $w == $somaDados)
        {
            $fim = false;
        }
        if($y + $w + $z == $somaDados)
        {
            $fim = false;
        }
        if($y + $z == $somaDados)
        {
            $fim = false;
        }
        if($w + $z == $somaDados)
        {
            $fim = false;
        }

        return $fim;
    }

    public function ck2($x, $y, $somaDados)
    {
        $fim = true;

        if($x + $y < $somaDados)
        {
            $fim = true;
        }
        else if($x + $y == $somaDados)
        {
            $fim = false;
        }
        else if($x == $somaDados )
        {
            $fim = false;
        }
        else if($y == $somaDados )
        {
            $fim = false;
        }

        return $fim;
    }

    public function ck1($x, $somaDados)
    {
        $fim = true;

        if($x == $somaDados )
        {
            $fim = false;
        }

        return $fim;
    }

    public function ck5($x, $y, $z, $h, $w, $somaDados)
    {
        $fim = true;

        if($x + $y + $z + $h + $w < $somaDados)
        {
            $fim = true;
        }
        else if($x + $y + $z + $h + $w == $somaDados)
        {
            $fim = false;
        }
        else if($x + $y + $z + $h == $somaDados)
        {
            $fim = false;
        }
        else if($x + $y + $z + $w == $somaDados) {
            $fim = false;
        }
        else if($x + $y + $z == $somaDados) {
            $fim = false;
        }
        else if($x + $y + $h + $w == $somaDados) {
            $fim = false;
        }
        else if($x + $y + $h == $somaDados) {
            $fim = false;
        }
        else if($x + $y + $w == $somaDados) {
            $fim = false;
        }
        else if($x + $z + $h + $w == $somaDados) {
            $fim = false;
        }
        else if($x + $z + $h == $somaDados) {
            $fim = false;
        }
        else if($x + $z + $w == $somaDados) {
            $fim = false;
        }
        else if($x + $h + $w == $somaDados) {
            $fim = false;
        }
        else if($x + $h == $somaDados) {
            $fim = false;
        }
        else if($x + $w == $somaDados) {
            $fim = false;
        }
        else if($x + $y == $somaDados) {
            $fim = false;
        }
        else if($x + $z == $somaDados) {
            $fim = false;
        }
        else if($y + $z + $h + $w == $somaDados) {
            $fim = false;
        }
        else if($y + $z + $h == $somaDados) {
            $fim = false;
        }
        else if($y + $z + $w == $somaDados) {
            $fim = false;
        }
        else if($y + $h + $w == $somaDados) {
            $fim = false;
        }
        else if($y + $h == $somaDados) {
            $fim = false;
        }
        else if ($y + $w == $somaDados) {
            $fim = false;
        }
        else if($y + $z == $somaDados) {
            $fim = false;
        }
        else if($z + $h + $w == $somaDados) {
            $fim = false;
        }
        else if($z + $w == $somaDados) {
            $fim = false;
        }
        else if($z + $h == $somaDados) {
            $fim = false;
        }
        else if($w + $h == $somaDados) {
            $fim = false;
        }
        else if($x == $somaDados){
            $fim = false;
        }
        else if($y == $somaDados){
            $fim = false;
        }
        else if($z == $somaDados){
            $fim = false;
        }
        else if($h == $somaDados){
            $fim = false;
        }
        else if($w == $somaDados){
            $fim = false;
        }

        return $fim;
    }

    public function getError()
    {

        return "Erro";
    }
}