<?php


class Score extends \ActiveRecord\Model
{
    static $validates_presence_of = array(
        array('iduser'),
        array('pontuacao'),
        array('dtapontuacao'),
    );
}