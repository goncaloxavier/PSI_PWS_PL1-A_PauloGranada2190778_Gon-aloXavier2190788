<?php


class User extends \ActiveRecord\Model
{
    static $validates_presence_of = array(
        array('iduser'),
        array('nome'),
        array('username', 'message' => 'exemplo'),
        array('password', 'message' => 'exemplo1'),
        array('dtanascimento', 'message' => 'exemplo2'),
        array('email', 'message' => 'exemplo3'),
    );
}