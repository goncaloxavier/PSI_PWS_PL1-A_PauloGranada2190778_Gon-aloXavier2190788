<?php
    use Carbon\Carbon;

    Class CalculadoraPlano{
        public function calculaPlanoAbatimentos($credito, $numPrest, $nPrestacaoAbater, $valorAbater){

            for ($i = 1; $i <= $numPrest; $i++){
                if($i + 1 == $nPrestacaoAbater){
                    $prestacoes[$i] = [round(($credito/$numPrest) , 2),round(($credito - $credito/$numPrest * $i) - $valorAbater, 2),  $valorAbater];
                }
                else{
                    $prestacoes[$i] = [round($credito/$numPrest, 2),round($credito - $credito/$numPrest * $i, 2), 0];
                }

            }
            return $prestacoes;
        }

        public function calculaPlano($credito, $numPrest){
            for ($i = 1; $i <= $numPrest; $i++){
                $prestacoes[$i] = [round($credito/$numPrest, 2),round($credito - $credito/$numPrest * $i, 2), 0];
            }
            return $prestacoes;
        }
    }