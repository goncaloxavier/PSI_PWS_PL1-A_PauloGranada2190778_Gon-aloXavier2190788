<?php
    Class DossierEmprestimo{
        public $Nome, $Credito, $NumPrestacoes, $PlanoPagamento;

        public function __construct($credito, $nome, $numPrestacoes) {
            $this -> Credito = $credito;
            $this -> Nome = $nome;
            $this -> NumPrestacoes = $numPrestacoes;
        }
    }