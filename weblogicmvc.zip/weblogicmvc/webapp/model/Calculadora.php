<?php


class Calculadora
{
    public function soma($val1, $val2){

        return $val1 + $val2;
    }

    public function sub($val1, $val2){

        return $val1 - $val2;
    }

    public function div($val1, $val2){

        return $val1 / $val2;
    }

    public function mult($val1, $val2){

        return $val1 * $val2;
    }
}