<?php
use ArmoredCore\WebObjects\View;
use ArmoredCore\WebObjects\Post;
use ArmoredCore\WebObjects\Layout;
class PlanoController extends \ArmoredCore\Controllers\BaseController
{
    public function index(){
        View::make('plano.index');
    }

    public function show(){

        $nome = Post::get('nome');
        $credito = Post::get('credito');
        $numPrest = Post::get('numPrest');

        $DossierEmprestimo = new DossierEmprestimo($credito, $nome, $numPrest);

        $PlanoPagamento = new CalculadoraPlano();
        $DossierEmprestimo -> PlanoPagamento = $PlanoPagamento -> calculaPlano($DossierEmprestimo -> Credito, $DossierEmprestimo -> NumPrestacoes);

        View::make('plano.show', ['PlanoPagamento' => $DossierEmprestimo -> PlanoPagamento]);
    }
}