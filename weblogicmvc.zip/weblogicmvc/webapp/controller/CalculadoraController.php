<?php
use ArmoredCore\WebObjects\View;
use ArmoredCore\WebObjects\Post;
use ArmoredCore\WebObjects\Layout;

class CalculadoraController extends \ArmoredCore\Controllers\BaseController
{
    public function index()
    {
        View::make('calculadora.index');
    }

    public function show()
    {
        $PlanoPagamento = new Calculadora();

        $value1 = Post::get('val1');
        $value2 = Post::get('val2');
        $opcao = Post::get('operacao');

        if($opcao == '+'){
            $soma = $PlanoPagamento ->soma($value1, $value2);
        }
        elseif ($opcao == '-'){
            $soma = $PlanoPagamento ->sub($value1, $value2);
        }
        elseif ($opcao == '/'){
            $soma = $PlanoPagamento ->div($value1, $value2);
        }
        elseif ($opcao == '*'){
            $soma = $PlanoPagamento ->mult($value1, $value2);
        }

        View::make('calculadora.show', ['soma' => $soma]);
    }
}