<?php

namespace ArmoredCore\Facades;
use ArmoredCore\Facades\Facade;

/**
 * Created by PhpStorm.
 * User: smendes
 * Date: 11-04-2017
 * Time: 12:24
 */
class AssetBundler extends Facade
{
    protected static function getName()
    {
        return 'Assetmanager';
    }
}